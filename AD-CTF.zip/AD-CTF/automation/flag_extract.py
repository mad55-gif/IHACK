import re
import sys

FLAG_PATTERN = re.compile(
    r'(?i)(?:flag|ctf)\{[^{}\r\n]+\}'
)

def extract_flags(text):
    return sorted(set(FLAG_PATTERN.findall(text)))

if __name__ == "__main__":
    content = sys.stdin.read()

    flags = extract_flags(content)

    for flag in flags:
        print(flag)

    print(f"\nTotal flags found: {len(flags)}")
