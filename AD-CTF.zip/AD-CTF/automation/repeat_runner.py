import subprocess
import time
import logging
from pathlib import Path

SCRIPT_DIR = Path.home() / "AD-CTF" / "exploits"
LOG_FILE = Path.home() / "AD-CTF" / "logs" / "runner.log"

logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s %(message)s"
)

INTERVAL = 60

while True:

    scripts = sorted(SCRIPT_DIR.glob("*.py"))

    for script in scripts:

        try:
            result = subprocess.run(
                ["python3", str(script)],
                capture_output=True,
                text=True,
                timeout=30
            )

            logging.info(
                "%s exit=%s output=%s",
                script.name,
                result.returncode,
                result.stdout[:1000]
            )

        except subprocess.TimeoutExpired:
            logging.warning("%s timed out", script.name)

        except Exception as error:
            logging.error("%s: %s", script.name, error)

    time.sleep(INTERVAL)
