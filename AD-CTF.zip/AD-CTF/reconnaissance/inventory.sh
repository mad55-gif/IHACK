#!/bin/bash

echo "===== SYSTEM INFORMATION ====="
hostname
ip addr

echo ""
echo "===== OPEN PORTS ====="
sudo ss -tulpn

echo ""
echo "===== RUNNING SERVICES ====="
systemctl --type=service --state=running

echo ""
echo "===== DOCKER CONTAINERS ====="
docker ps -a 2>/dev/null

echo ""
echo "===== COMPLETE ====="
