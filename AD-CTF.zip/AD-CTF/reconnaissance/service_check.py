import requests
from datetime import datetime

SERVICES = [
    "http://127.0.0.1:80",
    "http://127.0.0.1:8080",
    "http://127.0.0.1:5000"
]

for url in SERVICES:
    try:
        response = requests.get(url, timeout=3)

        print(
            datetime.now(),
            url,
            "ONLINE",
            response.status_code
        )

    except requests.RequestException:
        print(
            datetime.now(),
            url,
            "OFFLINE"
        )
