#!/bin/bash

echo "Monitoring authentication logs..."

sudo tail -F \
/var/log/auth.log \
/var/log/syslog
