#!/bin/bash

mkdir -p ~/AD-CTF/logs

INTERFACE="${1:-any}"

echo "Starting packet capture..."

sudo tcpdump \
-i "$INTERFACE" \
-n \
-s 0 \
-w ~/AD-CTF/logs/traffic.pcap
