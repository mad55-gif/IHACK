#!/bin/bash

echo "===== USERS ====="
cut -d: -f1 /etc/passwd

echo ""
echo "===== SUDO USERS ====="
getent group sudo

echo ""
echo "===== RUNNING PROCESSES ====="
ps aux --sort=-%cpu | head -20

echo ""
echo "===== LISTENING PORTS ====="
sudo ss -tulpn

echo ""
echo "===== CRON JOBS ====="
sudo ls -la /etc/cron.d/
sudo ls -la /etc/cron.daily/

echo ""
echo "===== SYSTEMD SERVICES ====="
systemctl list-units --type=service --state=running

echo ""
echo "===== COMPLETE ====="
