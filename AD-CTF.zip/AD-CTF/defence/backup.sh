#!/bin/bash

BACKUP="$HOME/AD-CTF/backups/$(date +%F_%H-%M-%S)"

mkdir -p "$BACKUP"

sudo cp -a /etc/ssh "$BACKUP/ssh"
sudo cp -a /etc/systemd/system "$BACKUP/systemd"

sudo chown -R "$USER":"$(id -gn)" "$BACKUP"

echo "Backup completed: $BACKUP"
