import requests
import time
from datetime import datetime

SERVICES = {
    "Web Server": "http://127.0.0.1:80",
    "Application": "http://127.0.0.1:8080",
    "API": "http://127.0.0.1:5000"
}

while True:
    for name, url in SERVICES.items():

        try:
            response = requests.get(url, timeout=3)

            status = f"ONLINE ({response.status_code})"

        except requests.RequestException:
            status = "OFFLINE"

        print(
            datetime.now().strftime("%H:%M:%S"),
            name,
            status
        )

    print("-" * 40)

    time.sleep(30)
